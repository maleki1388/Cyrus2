import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sing_box/sing_box.dart';

const Color cBg = Color(0xFF020611);
const Color cPanel = Color(0xFF091326);
const Color cCyan = Color(0xFF00D9FF);
const Color cPurple = Color(0xFFB52BFF);
const Color cGreen = Color(0xFF21E66B);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SingBox.instance.initialize(const SingBoxOptions(
    logMaxLines: 1500,
    android: SingBoxAndroidOptions(
      notificationTitle: 'CYRUS VPN',
      showTrafficInNotification: true,
      stopActionTitle: 'قطع اتصال',
    ),
  ));
  runApp(const CyrusApp());
}

class ServerProfile {
  final String id;
  final String link;
  final String name;

  const ServerProfile({required this.id, required this.link, required this.name});

  bool get isWireGuard {
    final s = link.trim().toLowerCase();
    if (s.startsWith('wireguard://') || s.startsWith('wg://')) return true;
    try {
      final decoded = jsonDecode(link);
      if (decoded is Map) {
        final outbounds = decoded['outbounds'];
        if (outbounds is List &&
            outbounds.any((e) => e is Map && e['type']?.toString() == 'wireguard')) {
          return true;
        }
        return decoded['type']?.toString() == 'wireguard' ||
            decoded['protocol']?.toString() == 'wireguard';
      }
    } catch (_) {}
    return false;
  }

  Map<String, dynamic> toJson() => {'id': id, 'link': link, 'name': name};

  factory ServerProfile.fromJson(Map<String, dynamic> json) => ServerProfile(
        id: json['id'] as String,
        link: json['link'] as String,
        name: json['name'] as String,
      );
}

class CyrusApp extends StatelessWidget {
  const CyrusApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CYRUS VPN',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: cBg,
        colorScheme: ColorScheme.fromSeed(
          seedColor: cCyan,
          brightness: Brightness.dark,
          surface: cPanel,
        ),
        useMaterial3: true,
      ),
      home: const CyrusHome(),
    );
  }
}

class CyrusHome extends StatefulWidget {
  const CyrusHome({super.key});

  @override
  State<CyrusHome> createState() => _CyrusHomeState();
}

class _CyrusHomeState extends State<CyrusHome> {
  final _client = SingBox.instance;
  final _input = TextEditingController();
  final _nameInput = TextEditingController();
  final List<ServerProfile> _profiles = [];
  StreamSubscription? _statusSub;
  StreamSubscription? _stateSub;
  StreamSubscription? _statsSub;
  int _tab = 0;
  String? _selectedId;
  bool _busy = false;
  String _state = 'disconnected';
  String _lastError = '';
  double _down = 0;
  double _up = 0;
  int _pingMs = 0;
  String _duration = '00:00';
  String _notice = 'آماده اتصال';
  bool _testing = false;

  bool get _connected => _state == 'connected';
  bool get _connecting => _state == 'connecting' || _state == 'disconnecting';
  ServerProfile? get _selected {
    for (final p in _profiles) {
      if (p.id == _selectedId) return p;
    }
    return _profiles.isEmpty ? null : _profiles.first;
  }

  List<ServerProfile> get _wireGuardProfiles =>
      _profiles.where((p) => p.isWireGuard).toList();
  List<ServerProfile> get _proxyProfiles =>
      _profiles.where((p) => !p.isWireGuard).toList();

  @override
  void initState() {
    super.initState();
    _loadProfiles();
    _status = _client.watchConnectionStatus().listen((s) {
      if (!mounted) return;
      setState(() => _state = s.name);
    });
    _stateSub = _client.watchConnectionState().listen((s) {
      if (!mounted) return;
      setState(() {
        _lastError = s.error?.toString() ?? '';
        if (_lastError.isNotEmpty) _notice = _lastError;
      });
    });
    _statsSub = _client.watchConnectionStats().listen((s) {
      if (!mounted) return;
      setState(() {
        _down = (s.downloadSpeed as num).toDouble();
        _up = (s.uploadSpeed as num).toDouble();
        _duration = s.duration.toString().split('.').first;
      });
    });
  }

  // Stream subscription is deliberately typed as dynamic to keep the UI
  // independent from package-internal status model names.
  StreamSubscription? _status;

  Future<void> _loadProfiles() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('cyrus_profiles');
    if (raw != null) {
      try {
        final list = jsonDecode(raw) as List;
        _profiles
          ..clear()
          ..addAll(list.map((e) => ServerProfile.fromJson(
              Map<String, dynamic>.from(e as Map))));
        _selectedId = prefs.getString('cyrus_selected');
      } catch (_) {
        _notice = 'فهرست کانفیگ‌ها قابل خواندن نبود';
      }
    }
    if (mounted) setState(() {});
  }

  Future<void> _saveProfiles() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      'cyrus_profiles',
      jsonEncode(_profiles.map((e) => e.toJson()).toList()),
    );
    if (_selectedId != null) {
      await prefs.setString('cyrus_selected', _selectedId!);
    } else {
      await prefs.remove('cyrus_selected');
    }
  }

  @override
  void dispose() {
    _input.dispose();
    _nameInput.dispose();
    _status?.cancel();
    _stateSub?.cancel();
    _statsSub?.cancel();
    super.dispose();
  }

  String _newId() => '${DateTime.now().microsecondsSinceEpoch}';

  Future<void> _addProfile() async {
    final link = _input.text.trim();
    if (link.isEmpty) return;
    final candidate = ServerProfile(id: 'check', link: link, name: 'check');
    final isWireGuard = candidate.isWireGuard;
    if (_tab == 2 && !isWireGuard) {
      _show('این بخش مخصوص کانفیگ WireGuard است');
      return;
    }
    if (_tab == 1 && isWireGuard) {
      _show('کانفیگ WireGuard را از بخش اختصاصی خودش اضافه کن');
      return;
    }
    final name = _nameInput.text.trim().isEmpty
        ? (link.split('#').length > 1 ? Uri.decodeComponent(link.split('#').last) : 'Server ${_profiles.length + 1}')
        : _nameInput.text.trim();
    final profile = ServerProfile(id: _newId(), link: link, name: name);
    setState(() {
      _profiles.insert(0, profile);
      _selectedId = profile.id;
      _input.clear();
      _nameInput.clear();
      _notice = profile.isWireGuard
          ? 'کانفیگ به بخش WireGuard اضافه شد'
          : 'کانفیگ اضافه شد';
    });
    await _saveProfiles();
  }

  Future<void> _paste() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    if (data?.text != null) {
      _input.text = data!.text!.trim();
      if (mounted) setState(() {});
    }
  }

  Future<void> _removeProfile(ServerProfile p) async {
    if (_connected && _selectedId == p.id) {
      _show('ابتدا اتصال فعلی را قطع کن');
      return;
    }
    setState(() {
      _profiles.removeWhere((x) => x.id == p.id);
      if (_selectedId == p.id) _selectedId = _profiles.isEmpty ? null : _profiles.first.id;
    });
    await _saveProfiles();
  }

  Future<void> _toggleConnection() async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      if (_connected || _connecting) {
        await _client.disconnect();
        if (mounted) setState(() => _notice = 'درخواست قطع اتصال ثبت شد');
      } else {
        final p = _selected;
        if (p == null) {
          _show('ابتدا یک کانفیگ اضافه و انتخاب کن');
          return;
        }
        setState(() {
          _notice = p.isWireGuard ? 'در حال راه‌اندازی WireGuard...' : 'در حال اتصال...';
          _lastError = '';
        });
        // sing-box serializes start/stop requests and reports exact failures.
        await _client.connect(p.link, timeout: const Duration(seconds: 40));
        if (mounted) setState(() => _notice = 'اتصال برقرار شد');
      }
    } on SingBoxCancelledException {
      if (mounted) setState(() => _notice = 'عملیات قبلی لغو شد');
    } catch (e) {
      if (mounted) {
        setState(() {
          _lastError = e.toString();
          _notice = 'اتصال ناموفق بود';
        });
      }
      _show('خطای اتصال: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _measurePing() async {
    if (!_connected || _testing) {
      _show('برای اندازه‌گیری پینگ، ابتدا متصل شو');
      return;
    }
    setState(() => _testing = true);
    try {
      final result = await _client.pingCurrentServer();
      final dynamic r = result;
      final value = r.ping;
      if (mounted) {
        setState(() {
          _pingMs = value is num ? value.round() : 0;
          _notice = _pingMs > 0 ? 'پینگ از داخل تونل اندازه‌گیری شد' : 'پینگ دریافت نشد';
        });
      }
    } catch (e) {
      _show('اندازه‌گیری پینگ ناموفق بود: $e');
    } finally {
      if (mounted) setState(() => _testing = false);
    }
  }

  Future<void> _measureSpeed() async {
    if (!_connected || _testing) {
      _show('برای تست سرعت، ابتدا متصل شو');
      return;
    }
    setState(() => _testing = true);
    try {
      final result = await _client.testSpeed();
      final dynamic r = result;
      if (mounted) {
        setState(() {
          _down = (r.downloadMbps as num).toDouble() * 125000;
          _up = (r.uploadMbps as num).toDouble() * 125000;
          _notice = 'تست سرعت واقعی انجام شد';
        });
      }
    } catch (e) {
      _show('تست سرعت ناموفق بود: $e');
    } finally {
      if (mounted) setState(() => _testing = false);
    }
  }

  void _show(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  String _rate(double bytes) {
    if (bytes >= 1024 * 1024) return '${(bytes / 1024 / 1024).toStringAsFixed(1)} MB/s';
    if (bytes >= 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB/s';
    return '${bytes.toStringAsFixed(0)} B/s';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: IndexedStack(
          index: _tab,
          children: [
            _homePage(),
            _configPage(_proxyProfiles, 'کانفیگ‌های معمولی'),
            _configPage(_wireGuardProfiles, 'WireGuard'),
            _statsPage(),
            _settingsPage(),
          ],
        ),
      ),
      bottomNavigationBar: _bottomNav(),
    );
  }

  Widget _header({String subtitle = 'SECURE CONNECTION'}) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 10),
      child: Row(
        children: [
          const Icon(Icons.menu_rounded, color: cCyan, size: 28),
          const Spacer(),
          Column(
            children: const [
              Text('CYRUS', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900, letterSpacing: 2)),
              Text('VPN', style: TextStyle(color: cPurple, fontSize: 22, fontWeight: FontWeight.w900, letterSpacing: 5)),
            ],
          ),
          const Spacer(),
          IconButton(
            onPressed: () => setState(() => _tab = 4),
            icon: const Icon(Icons.palette_outlined, color: cCyan),
          ),
        ],
      ),
    );
  }

  Widget _homePage() {
    final p = _selected;
    return ListView(
      padding: EdgeInsets.zero,
      children: [
        _header(),
        Center(
          child: Container(
            margin: const EdgeInsets.only(top: 4, bottom: 20),
            padding: const EdgeInsets.symmetric(horizontal: 26, vertical: 10),
            decoration: BoxDecoration(
              border: Border.all(color: _connected ? cGreen : cCyan.withOpacity(.55)),
              borderRadius: BorderRadius.circular(30),
              color: cPanel,
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.circle, size: 12, color: _connected ? cGreen : Colors.orangeAccent),
              const SizedBox(width: 10),
              Text(_connected ? 'Connected' : _connecting ? 'Connecting' : 'Disconnected',
                  style: TextStyle(color: _connected ? cGreen : Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
            ]),
          ),
        ),
        Center(
          child: GestureDetector(
            onTap: _busy ? null : _toggleConnection,
            child: Container(
              width: 252,
              height: 252,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color(0xFF050B1B),
                border: Border.all(color: cCyan, width: 4),
                boxShadow: [
                  BoxShadow(color: cCyan.withOpacity(.35), blurRadius: 30, spreadRadius: 5),
                  BoxShadow(color: cPurple.withOpacity(.25), blurRadius: 45, spreadRadius: 8),
                ],
              ),
              child: Container(
                margin: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: cPurple, width: 2),
                ),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(_connected ? Icons.lock : Icons.shield_outlined, color: cCyan, size: 54),
                  const SizedBox(height: 12),
                  Text(_busy ? 'Please wait' : _connected ? 'Disconnect' : 'Connect',
                      style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 5),
                  Text(_busy ? 'Managing tunnel' : _connected ? 'Tap to disconnect' : 'Tap to connect',
                      style: const TextStyle(color: Colors.white70)),
                ]),
              ),
            ),
          ),
        ),
        const SizedBox(height: 24),
        _serverCard(p),
        const SizedBox(height: 14),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(children: [
            Expanded(child: _metricCard('Ping', _pingMs > 0 ? '$_pingMs ms' : '—', Icons.bolt, cPurple,
                onTap: _measurePing)),
            const SizedBox(width: 12),
            Expanded(child: _metricCard('Download', _rate(_down), Icons.download, cCyan)),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Row(children: [
            Expanded(child: _metricCard('Upload', _rate(_up), Icons.upload, cPurple)),
            const SizedBox(width: 12),
            Expanded(child: _metricCard('Duration', _duration, Icons.timer_outlined, cCyan)),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: OutlinedButton.icon(
            onPressed: _connected && !_testing ? _measureSpeed : null,
            icon: const Icon(Icons.speed),
            label: Text(_testing ? 'در حال آزمایش...' : 'آزمایش واقعی سرعت'),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
          child: Text(_lastError.isNotEmpty ? _lastError : _notice,
              textAlign: TextAlign.center, style: const TextStyle(color: Colors.white60, fontSize: 12)),
        ),
      ],
    );
  }

  Widget _serverCard(ServerProfile? p) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: InkWell(
        onTap: () => setState(() => _tab = p?.isWireGuard == true ? 2 : 1),
        borderRadius: BorderRadius.circular(18),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: cPurple),
            gradient: const LinearGradient(colors: [Color(0xFF111A3A), Color(0xFF070D1B)]),
          ),
          child: Row(children: [
            const Icon(Icons.public, color: cGreen, size: 34),
            const SizedBox(width: 14),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(p?.name ?? 'No server selected', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
              Text(p == null ? 'Add a configuration' : p.isWireGuard ? 'WIREGUARD • SING-BOX' : 'PROXY • SING-BOX',
                  style: const TextStyle(color: Colors.white60, fontSize: 12)),
            ])),
            const Icon(Icons.chevron_right, color: cPurple, size: 30),
          ]),
        ),
      ),
    );
  }

  Widget _metricCard(String title, String value, IconData icon, Color color, {VoidCallback? onTap}) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: Container(
        height: 112,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: cPanel,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: color.withOpacity(.65)),
          boxShadow: [BoxShadow(color: color.withOpacity(.12), blurRadius: 15)],
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Icon(icon, color: color),
            const SizedBox(width: 8),
            Text(title, style: const TextStyle(color: Colors.white70)),
          ]),
          const Spacer(),
          FittedBox(fit: BoxFit.scaleDown, child: Text(value,
              style: TextStyle(color: color, fontSize: 23, fontWeight: FontWeight.w800))),
        ]),
      ),
    );
  }

  Widget _configPage(List<ServerProfile> profiles, String title) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        Text(title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        TextField(
          controller: _nameInput,
          decoration: const InputDecoration(labelText: 'نام سرور', prefixIcon: Icon(Icons.label_outline)),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _input,
          minLines: 2,
          maxLines: 5,
          decoration: InputDecoration(
            labelText: 'لینک یا JSON کانفیگ',
            hintText: 'vless:// ، vmess:// ، wireguard:// ...',
            border: const OutlineInputBorder(),
            suffixIcon: IconButton(onPressed: _paste, icon: const Icon(Icons.content_paste)),
          ),
        ),
        const SizedBox(height: 10),
        FilledButton.icon(onPressed: _addProfile, icon: const Icon(Icons.add), label: const Text('افزودن کانفیگ')),
        const SizedBox(height: 18),
        if (profiles.isEmpty)
          const Padding(
            padding: EdgeInsets.all(24),
            child: Text('هنوز کانفیگی در این بخش وجود ندارد', textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white60)),
          ),
        ...profiles.map((p) => Card(
          color: cPanel,
          child: ListTile(
            leading: Icon(p.isWireGuard ? Icons.vpn_lock : Icons.dns, color: p.isWireGuard ? cPurple : cCyan),
            title: Text(p.name),
            subtitle: Text(p.isWireGuard ? 'WireGuard' : 'Proxy configuration',
                style: const TextStyle(color: Colors.white60)),
            selected: p.id == _selectedId,
            selectedTileColor: cCyan.withOpacity(.08),
            onTap: () async {
              if (_connected && _selectedId != p.id) {
                _show('برای تغییر سرور ابتدا اتصال را قطع کن');
                return;
              }
              setState(() {
                _selectedId = p.id;
                _notice = 'سرور انتخاب شد';
              });
              await _saveProfiles();
            },
            trailing: IconButton(
              icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
              onPressed: () => _removeProfile(p),
            ),
          ),
        )),
      ],
    );
  }

  Widget _statsPage() {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        const Text('آمار اتصال', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 18),
        _metricCard('Download', _rate(_down), Icons.download, cCyan),
        const SizedBox(height: 12),
        _metricCard('Upload', _rate(_up), Icons.upload, cPurple),
        const SizedBox(height: 12),
        _metricCard('Ping', _pingMs > 0 ? '$_pingMs ms' : '—', Icons.bolt, cPurple, onTap: _measurePing),
        const SizedBox(height: 12),
        _metricCard('Duration', _duration, Icons.timer, cCyan),
        const SizedBox(height: 20),
        Text(_lastError.isEmpty ? _notice : _lastError, style: const TextStyle(color: Colors.white60)),
      ],
    );
  }

  Widget _settingsPage() {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        const Text('تنظیمات CYRUS', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 14),
        const ListTile(
          leading: Icon(Icons.security, color: cCyan),
          title: Text('موتور اتصال'),
          subtitle: Text('Sing-box • یک موتور واحد برای پروتکل‌ها و WireGuard'),
        ),
        const ListTile(
          leading: Icon(Icons.speed, color: cPurple),
          title: Text('پینگ و سرعت'),
          subtitle: Text('اندازه‌گیری واقعی؛ بدون عدد نمایشی'),
        ),
        const ListTile(
          leading: Icon(Icons.palette, color: cCyan),
          title: Text('پوسته'),
          subtitle: Text('سرمه‌ای تیره، آبی نئونی و بنفش'),
        ),
        const Divider(),
        const Text('نسخه 4.6.0 • CYRUS VPN', textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white54)),
      ],
    );
  }

  Widget _bottomNav() {
    const items = [
      (Icons.home_rounded, 'Home'),
      (Icons.layers_rounded, 'Configs'),
      (Icons.bolt_rounded, 'WireGuard'),
      (Icons.bar_chart_rounded, 'Statistics'),
      (Icons.settings_rounded, 'Settings'),
    ];
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF050A17),
        border: Border(top: BorderSide(color: cPurple.withOpacity(.6))),
        boxShadow: [BoxShadow(color: cCyan.withOpacity(.12), blurRadius: 18)],
      ),
      child: SafeArea(
        top: false,
        child: Row(
          children: List.generate(items.length, (i) {
            final item = items[i];
            final selected = _tab == i;
            return Expanded(
              child: InkWell(
                onTap: () => setState(() => _tab = i),
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Icon(item.$1, color: selected ? cCyan : Colors.white60, size: 25),
                    const SizedBox(height: 4),
                    Text(item.$2, style: TextStyle(
                      color: selected ? cCyan : Colors.white60,
                      fontSize: 11,
                      fontWeight: selected ? FontWeight.bold : FontWeight.normal,
                    )),
                  ]),
                ),
              ),
            );
          }),
        ),
      ),
    );
  }
}
